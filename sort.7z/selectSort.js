function selectSort (arr) {
  for(let i = 0;i<arr.length)
}

module.exports=selectSort;
